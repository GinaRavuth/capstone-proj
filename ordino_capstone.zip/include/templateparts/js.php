<!-- Scripts -->
<script type="text/javascript" src="https://cdn.datatables.net/t/bs/jq-2.2.0,dt-1.10.11,fh-3.1.1,r-2.0.2,se-1.1.2/datatables.min.js"></script>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<!-- End scripts -->