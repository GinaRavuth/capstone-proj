<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
		<div class="navbar-header">
            <button type="button" class="navbar-toggle toggle-button" data-toggle="collapse" data-target="#navbar-collapse-main" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
				<a class="navbar-brand" href="../index.html">
				<h1 id="ordino">Ordino</h1>
				</a>
            </div>
            <div class="collapse navbar-collapse nav-right" id="navbar-collapse-main" aria-expanded="false">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.html" class="active">Home</a>
                    </li>
                    <li>
                        <a href="hardware.php">Hardware</a>
                    </li>
                    <li>
                       <a href="about.php">About</a>
                    </li>
                    <li>
                        <a href="returns.php">Returns</a>
                    </li>
				</ul>
			</div>
		</div>
    </div> 
</nav>
<!-- End navigation -->