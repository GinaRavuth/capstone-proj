<!-- CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/local.css">
<link rel="icon" type="image/png" href="css/favicon-32x32.png" sizes="32x32">
<link href='http://fonts.googleapis.com/css?family=Quicksand:400,300,700%7COpen Sans:400,300,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/t/bs/jq-2.2.0,dt-1.10.11,fh-3.1.1,r-2.0.2,se-1.1.2/datatables.min.css"/>
<!-- End CSS -->