<!-- Admin dashboard script links -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="admin_functions/checkout/checkout_functions.js"></script>
<script type="text/javascript" src="admin_functions/admin_functions.js"></script>
<!-- End script links -->