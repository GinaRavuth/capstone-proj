$(document).ready(function() {
    $('#table-id').dataTable();
} );